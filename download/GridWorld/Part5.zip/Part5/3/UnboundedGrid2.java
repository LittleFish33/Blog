
import java.util.ArrayList;
import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

public class UnboundedGrid2<E> extends AbstractGrid<E>{

    private Object[][] occupantArray; // the array storing the grid elements
    private int row;
    private int col;

    /**
     * Constructs an empty bounded grid with the given dimensions.
     * (Precondition: <code>rows > 0</code> and <code>cols > 0</code>.)
     * @param rows number of rows in BoundedGrid
     * @param cols number of columns in BoundedGrid
     */
    public UnboundedGrid2()
    {
        this.row = 16;
        this.col = 16;
        this.occupantArray = new Object[row][col];
    }
    
    
    @SuppressWarnings("unchecked")
    @Override
    public E get(Location loc) {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        //double both array bounds until they are large enough
        while(loc.getRow() >= row || loc.getCol() >= col) {
            doubleGrid();
        }
        return (E) occupantArray[loc.getRow()][loc.getCol()]; // unavoidable warning
    }

    //double the row and the column, double both array bounds until
    private void doubleGrid() {
        row *= 2;
        col *= 2;
        Object[][] newArray = new Object[row][col];
        for(int i = 0;i < row/2;i++) {
            for (int j = 0; j < col/2; j++) {
                newArray[i][j] = occupantArray[i][j];
            }
        }
        occupantArray = newArray;
    }

    //make it be a UnboundedGrid
    @Override
    public int getNumCols() {
        return -1;
    }

    @Override
    public int getNumRows() {
        return -1;
    }

    @Override
    public ArrayList<Location> getOccupiedLocations() {
        ArrayList<Location> theLocations = new ArrayList<Location>();

        // Look at all grid locations.
        for (int r = 0; r < row; r++)
        {
            for (int c = 0; c < col; c++)
            {
                Location loc = new Location(r, c);
                if (get(loc) != null)
                    theLocations.add(loc);
            }
        }

        return theLocations;
    }

    @Override
    public boolean isValid(Location loc) {
        return 0 <= loc.getRow() && 0 <= loc.getCol();
    }

    @Override
    public E put(Location loc, E obj) {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        if (obj == null)
            throw new NullPointerException("obj == null");
      //double both array bounds until they are large enough
        while(loc.getRow() > row || loc.getCol() > col) {
            doubleGrid();
        }

        E oldOccupant = get(loc);
        occupantArray[loc.getRow()][loc.getCol()] = obj;
        return oldOccupant;
    }

    @Override
    public E remove(Location loc) {
        if (!isValid(loc))
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        if(loc.getRow() > row || loc.getCol() > col) {
            return null;
        }
        
        // Remove the object from the grid.
        E r = get(loc);
        occupantArray[loc.getRow()][loc.getCol()] = null;
        return r;
    }

}
