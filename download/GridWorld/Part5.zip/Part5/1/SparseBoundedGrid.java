
import java.util.ArrayList;

import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

/**
 * A <code>SparseBoundedGrid</code> is a grid with a finite number of
 * rows and columns, using list to create <br />
 * The implementation of this class is testable on the AP CS AB exam.
 */
public class SparseBoundedGrid<E> extends AbstractGrid<E> {

    private SparseGridNode occupantList[];
    private int col;
    private int row;
    
    /**
     * Constructs an empty bounded grid with the given dimensions to initialize list.
     * (Precondition: <code>rows > 0</code> and <code>cols > 0</code>.)
     * @param rows number of rows in BoundedGrid
     * @param cols number of columns in BoundedGrid
     */
    public SparseBoundedGrid(int rows, int cols) {
        if (rows <= 0){
            throw new IllegalArgumentException("rows <= 0");
        }
        if (cols <= 0){
            throw new IllegalArgumentException("cols <= 0");
        }
        occupantList  = new SparseGridNode[rows];
        this.col = cols;
        this.row = rows;
    }

    @SuppressWarnings("unchecked")
    @Override
    public E get(Location loc) {
        if (!isValid(loc)){
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        }
        SparseGridNode node = occupantList[loc.getRow()];
        //check if the node exist
        while(node != null) {
            if(node.getCol() == loc.getCol()) {
                 // unavoidable warning
                return (E)node.getOccupant();
            }
            else {
                node = node.getNext();
            }
        }
        return null;
    }

    @Override
    public int getNumCols() {
        // Note: according to the constructor precondition, numRows() > 0, so
        // theGrid[0] is non-null.
        return col;
    }

    @Override
    public int getNumRows() {
        return row;
    }

    @Override
    public ArrayList<Location> getOccupiedLocations() {
        ArrayList<Location> theLocations = new ArrayList<Location>();

        // Look at all grid locations.
        for (int r = 0; r < row; r++)
        {
            SparseGridNode node = occupantList[r];
            while(node != null) {
                Location location = new Location(r, node.getCol());
                theLocations.add(location);
                node = node.getNext();
            }
        }

        return theLocations;
    }

    
    @Override
    public boolean isValid(Location loc) {
        if(0 <= loc.getRow() && loc.getRow() < getNumRows()
                && 0 <= loc.getCol() && loc.getCol() < getNumCols()){
                return true;       
         }
         return false;
    }

    @Override
    public E put(Location loc, E obj) {
        if (!isValid(loc)){
            throw new IllegalArgumentException("The Location " + loc
                    + " is not valid");
        }
        if (obj == null){
            return null;
        }
        // Add the object to the grid.
        E oldOccupant = get(loc);
        SparseGridNode newOccupant = new SparseGridNode(obj, loc.getCol());
        SparseGridNode node = occupantList[loc.getRow()];
        if(node == null) {
            occupantList[loc.getRow()] = newOccupant;
        }
        else {
            while(node.getNext() != null) {
                node = node.getNext();
            }
            node.setNext(newOccupant);
        }
        return oldOccupant;
    }

    @Override
    public E remove(Location loc) {
        if (!isValid(loc)){
            throw new IllegalArgumentException("Location " + loc
                    + " is not valid");
        }
        
        // Remove the object from the grid.
        E r = get(loc);
        if(r != null) {
            SparseGridNode node = occupantList[loc.getRow()];
            if(node.getCol() == loc.getCol()) {
                occupantList[loc.getRow()] = node.getNext();
            }
            else {
                while(node.getNext().getCol() != loc.getCol()) {
                    node = node.getNext();
                }
                node.setNext(node.getNext().getNext());
            }
        }
        return r;
    }
    
}
