
public class SparseGridNode {
    private Object occupant;
    private int col;
    private SparseGridNode next;
    
    /**
     * Constructs a SparseGridNode with the given dimensions.
     * (Precondition: <code>obj != null</code> and <code>c > 0</code>.)
     * @param obj is the occupant contain in Node 
     * @param cols number of columns in BoundedGrid
     * next = null
     */
    public SparseGridNode(Object obj,int c) {
        this.occupant =  obj;
        this.col = c;
        this.next = null;
    }
    
    /**
     * the param compared to the first Constructor contain a SparseGridNode
     * which is the next value
     */ 
    public SparseGridNode(Object obj,int c,SparseGridNode node) {
        this.occupant =  obj;
        this.col = c;
        this.next = node;
    }

 
    public Object getOccupant() {
        return occupant;
    }

    public void setOccupant(Object occupant) {
        this.occupant = occupant;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public SparseGridNode getNext() {
        return next;
    }

    public void setNext(SparseGridNode next) {
        this.next = next;
    }
    
}
