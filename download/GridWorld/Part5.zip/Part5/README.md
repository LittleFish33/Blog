### SparseBoundedGrid

#### Ⅰ Implement

The code in the folder 1 is sparse array implement using linked list， it has a array, the size of the array represent the row in the grid, and each element in the array is a SparseGridNode, together, it create a linked list.

#### Ⅱ SparseGridNode

The `SparseGridNode.java` is the structure that we make to contain the data, it has three parameters:

```java
public class SparseGridNode {
    private Object occupant;
    private int col;
    private SparseGridNode next;
    
    /**
     * Constructs a SparseGridNode with the given dimensions.
     * (Precondition: <code>obj != null</code> and <code>c > 0</code>.)
     * @param obj is the occupant contain in Node 
     * @param cols number of columns in BoundedGrid
     * next = null
     */
    public SparseGridNode(Object obj,int c) {
        this.occupant =  obj;
        this.col = c;
        this.next = null;
    }
    //......
}
```

* occupant contain the value of the data, the col represent what col the Node is in the row, the SparseBoundedGrid.java has a array that contain n SparseGridNode, which stands for n row, and the next represent the value next to the node, it there is no node next to it,l the next will be null.

#### Ⅲ SparseBoundedGrid

* In the get method, it use a loop to get the object:

```java
@SuppressWarnings("unchecked")
@Override
public E get(Location loc) {
    if (!isValid(loc)){
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    }
    SparseGridNode node = occupantList[loc.getRow()];
    //check if the node exist
    while(node != null) {
        if(node.getCol() == loc.getCol()) {
            // unavoidable warning
            return (E)node.getOccupant();
        }
        else {
            node = node.getNext();
        }
    }
    return null;
}
```

* And in the put method， it use the same way to deal with it.

```java
@Override
public E put(Location loc, E obj) {
    if (!isValid(loc)){
        throw new IllegalArgumentException("The Location " + loc
                                           + " is not valid");
    }
    if (obj == null){
        return null;
    }
    // Add the object to the grid.
    E oldOccupant = get(loc);
    SparseGridNode newOccupant = new SparseGridNode(obj, loc.getCol());
    SparseGridNode node = occupantList[loc.getRow()];
    if(node == null) {
        occupantList[loc.getRow()] = newOccupant;
    }
    else {
        while(node.getNext() != null) {
            node = node.getNext();
        }
        node.setNext(newOccupant);
    }
    return oldOccupant;
}
```

* In the remove method, if the Location doesn't contain a object, return null, else, return the object

```java
public E remove(Location loc) {
    if (!isValid(loc)){
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    }

    // Remove the object from the grid.
    E r = get(loc);
    if(r != null) {
        SparseGridNode node = occupantList[loc.getRow()];
        if(node.getCol() == loc.getCol()) {
            occupantList[loc.getRow()] = node.getNext();
        }
        else {
            while(node.getNext().getCol() != loc.getCol()) {
                node = node.getNext();
            }
            node.setNext(node.getNext().getNext());
        }
    }
    return r;
}

```



***

### SparseBoundedGrid2

#### Ⅰ  Implement

* The code in the folder 2 is `SparseBoundedGrid` using `HashMap` .
* Use the Location as the key, and the E as the value

```java
private Map<Location, E> occupantMap;
```

#### Ⅱ SparseBoundedGrid2

* The get method just use the get method of the Map

```java
@Override
public E get(Location loc) {
    if (!isValid(loc)){
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    }
    return occupantMap.get(loc);
}
```

* The remove method just use the remove method of the Map

```java
@Override
public E remove(Location loc) {
    if (!isValid(loc)){
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    }

    // Remove the object from the grid.
    E value = occupantMap.get(loc);
    occupantMap.remove(loc);
    return value;
}
```

* The put method just use the put method of the Map

```java
@Override
public E put(Location loc, E obj) {
    if (!isValid(loc)){
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    }
    if (obj == null){
        return null;
    }
    //check if the obj exist
    if(occupantMap.containsKey(loc)) {
        E value = occupantMap.get(loc);
        occupantMap.put(loc, obj);
        return value;
    }
    else {
        occupantMap.put(loc, obj);
        return null;
    }
}
```

***

### UnboundedGrid2

#### Ⅰ  Implement

* The code in the folder 2 is `UnboundedGrid2` using ` dynamic array` . When the put method need to put a location that is out of the grid, the grid will expand itself to make it fit.

#### Ⅱ UnboundedGrid2

* The default size of the grid is 16

```java
public UnboundedGrid2()
{
    this.row = 16;
    this.col = 16;
    this.occupantArray = new Object[row][col];
}
```

* The get method, if the location if out of the grid, it will expand the grid.

```java
@SuppressWarnings("unchecked")
@Override
public E get(Location loc) {
    if (!isValid(loc))
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    //double both array bounds until they are large enough
    while(loc.getRow() >= row || loc.getCol() >= col) {
        doubleGrid();
    }
    return (E) occupantArray[loc.getRow()][loc.getCol()]; // unavoidable warning
}
```

* Also, the put method

```java
@Override
public E put(Location loc, E obj) {
    if (!isValid(loc))
        throw new IllegalArgumentException("Location " + loc
                                           + " is not valid");
    if (obj == null)
        throw new NullPointerException("obj == null");
    //double both array bounds until they are large enough
    while(loc.getRow() > row || loc.getCol() > col) {
        doubleGrid();
    }

    E oldOccupant = get(loc);
    occupantArray[loc.getRow()][loc.getCol()] = obj;
    return oldOccupant;
}
```

* And the method that expand the grid 

```java
//double the row and the column, double both array bounds until
private void doubleGrid() {
    row *= 2;
    col *= 2;
    Object[][] newArray = new Object[row][col];
    for(int i = 0;i < row/2;i++) {
        for (int j = 0; j < col/2; j++) {
            newArray[i][j] = occupantArray[i][j];
        }
    }
    occupantArray = newArray;
}
```













