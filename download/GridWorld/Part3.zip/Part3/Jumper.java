import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class Jumper extends Actor {
    
    /**
     * override the act method, make it move two step
     * @param length the side length
     */    
    @Override
    public void act() {
        Location now = this.getLocation();
        Location destination = now.getAdjacentLocation(getDirection()).getAdjacentLocation(getDirection());
        Grid<Actor> grid = this.getGrid();
        if(grid.isValid(destination) && (grid.get(destination) == null || grid.get(destination) instanceof Flower )) {
            this.moveTo(destination);
        }
        else {
            this.setDirection(getDirection() + 45);
        }
    }

}
