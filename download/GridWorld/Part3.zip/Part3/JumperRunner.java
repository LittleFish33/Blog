
import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;


/**
 * This class runs a world that contains Jumper. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public final class JumperRunner {
    
    private JumperRunner(){}
    
    public static void main(String[] args) {
        ActorWorld world = new ActorWorld();
        Jumper alice = new Jumper();
        alice.setColor(Color.green);
        Rock rock = new Rock();
        world.add(new Location(5, 8),rock);
        world.add(new Location(7, 8), alice);
        world.show();
    }
}
