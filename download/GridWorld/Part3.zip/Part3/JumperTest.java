import static org.junit.Assert.*;
import org.junit.Test;


import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;


public class JumperTest {
    public ActorWorld world = new ActorWorld();
    public Jumper alice = new Jumper();


    @Test
    public void testJump() {
    	world.add(new Location(7, 8), alice);
    	alice.act();
        Location loc = alice.getLocation();
        Location loc2 = new Location(5, 8);
        assertEquals(loc, loc2);
    }
    
    @Test
    public void testFlower() {
    	world.add(new Location(5, 8),new Flower());
    	world.add(new Location(7, 8), alice);
    	alice.act();
        assertTrue(alice.getLocation().equals(new Location(5, 8)));
    }
    
    @Test
    public void testRock() {
    	world.add(new Location(7, 8), alice);
    	alice.act();
        Location loc = alice.getLocation();
        Location loc2 = new Location(5, 8);
        assertEquals(loc, loc2);
    }

    @Test
    public void testGetDirection() {
    	world.add(new Location(5, 8),new Rock());
    	world.add(new Location(7, 8), alice);
    	alice.act();
        assertTrue(alice.getLocation().equals(new Location(7, 8)));
    }
    
    @Test
    public void testTurn() {
    	world.add(new Location(5, 8),new Rock());
    	world.add(new Location(7, 8), alice);
    	alice.act();
        int direc = alice.getDirection();
        assertTrue(direc == Location.NORTHEAST);
    }
    
    
    @Test
    public void testFaceGrid() {
    	world.add(new Location(0, 0), alice);
    	alice.act();
        assertTrue(alice.getDirection() == Location.NORTHEAST);
    }
    
    @Test
    public void testEncounterJumper() {
    	Jumper blob = new Jumper();
    	blob.setDirection(Location.SOUTH);
    	world.add(new Location(3, 8), blob);
    	world.add(new Location(7, 8), alice);
    	blob.act();
    	alice.act();
    	assertTrue(blob.getLocation().equals(new Location(5, 8)));
        assertTrue(alice.getDirection() == Location.NORTHEAST);
    }
    
    
}

