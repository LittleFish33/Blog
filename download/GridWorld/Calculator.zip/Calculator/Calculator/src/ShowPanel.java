
import java.awt.Button;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class ShowPanel extends JPanel{
	//use the textfield to show the command 
	private JTextField num1;	
	private JTextField operator;
	private JTextField num2;
	private JTextField equal;
	private JTextField result;
	
	//use the button to operate
	private Button addButton;
	private Button subButton;
	private Button multButton;
	private Button divButton;
	private Button okButton;
	
	//button event listener
	private ActionListener listener = new ActionListener() {  
        public void actionPerformed(ActionEvent e) {  
			String text = ((Button)e.getSource()).getLabel();
			//text.length != 1, so the text is "ok"
			if(text.length() == 1) {
				operator.setText(text);
			}
			else {
				if(num1.getText().length() == 0 || num2.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "运算数不能为空");
				}
				else if(Integer.parseInt(num2.getText()) == 0 && operator.getText().equals("/")) {
					JOptionPane.showMessageDialog(null, "除数不能为0");
				}
				else {
					calculate();	
				}
			}
        }  
    };
    
    
    public void calculate(){
    	
		//calculate
		double res;
		switch (operator.getText()) {
		case "+":
			res = Double.valueOf(num1.getText()) + Double.valueOf(num2.getText());
			result.setText(String.valueOf(res));
			break;
		case "-":
			res = Double.valueOf(num1.getText()) - Double.valueOf(num2.getText());
			result.setText(String.valueOf(res));
			break;
		case "X":
			res = Double.valueOf(num1.getText()) * Double.valueOf(num2.getText());
			result.setText(String.valueOf(res));
			break;
		case "/":
			res = Double.valueOf(num1.getText()) / Double.valueOf(num2.getText());
			result.setText(String.valueOf(res));
			break;
		default:
			break;
		}
    }
	
	public ShowPanel() {
		//set the layout
		this.setLayout(new GridLayout(2, 5, 3, 3));
		//generate the textfield and button
		num1 = new JTextField("");
		num1.setDocument(new NumberOnlyLimitedDmt());
		operator = new JTextField("+");
		num2 = new JTextField("");
		num2.setDocument(new NumberOnlyLimitedDmt());
		equal = new JTextField("=");
		result = new JTextField("");
		
		num1.setHorizontalAlignment(JTextField.CENTER);
		operator.setHorizontalAlignment(JTextField.CENTER);
		num2.setHorizontalAlignment(JTextField.CENTER);
		equal.setHorizontalAlignment(JTextField.CENTER);
		result.setHorizontalAlignment(JTextField.CENTER);
		
		operator.setEditable(false);
		equal.setEditable(false);
		result.setEditable(false);
		
		this.add(num1);
		this.add(operator);
		this.add(num2);
		this.add(equal);
		this.add(result);
		
		addButton = new Button("+");
		subButton = new Button("-");
		multButton = new Button("X");
		divButton = new Button("/");
		okButton = new Button("OK");
		
		//add the function when you click the button
		addButton.addActionListener(listener);
		subButton.addActionListener(listener);
		multButton.addActionListener(listener);
		divButton.addActionListener(listener);
		okButton.addActionListener(listener);
		
		this.add(addButton);
		this.add(subButton);
		this.add(multButton);
		this.add(divButton);
		this.add(okButton);
	}
	
}
class NumberOnlyLimitedDmt extends PlainDocument {
	 
	public NumberOnlyLimitedDmt() {
	   super();
	} 
	public void insertString(int offset, String  str, AttributeSet attr)throws BadLocationException {
       char[] upper = str.toCharArray();
       int length=0;
       for (int i = 0; i < upper.length; i++) {      
           if (upper[i]>='0' && upper[i] <= '9'){
        	   upper[length++] = upper[i];
           }
       }
       super.insertString(offset, new String(upper,0,length),attr);
	}
}

