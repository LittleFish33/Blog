
import javax.swing.JFrame;

public class Calculator extends JFrame{
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		calculator.setUI();
	}
	
	public Calculator() {
		//create a frame
		super("Calculator");		
	}
	
	public void setUI() {
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(400,200);
		this.setResizable(false);
		this.add(new ShowPanel());
		this.add(new ShowPanel());                                   
		this.setVisible(true);
	}
	
}















    
