package imageprocessing;

import static org.junit.Assert.assertTrue;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;

import org.junit.Test;

/**
 * This class test the  ImplementImageIO class and ImplementProcessor class <br />
 * It first construct a testProcessor and a testImageIO
 * all test should return true
 */
public class ImageProcessorTest {
    /*
     * Two class we need to test
     */
    private ImplementImageProcessor testProcessor = new ImplementImageProcessor(); 
    private ImplementImageIO testImageIo = new ImplementImageIO();
    private String image1Path = "/home/qiuxy/Desktop/final/ImageProcessing/bmptest/1.bmp";
    private String image2Path = "/home/qiuxy/Desktop/final/ImageProcessing/bmptest/2.bmp";
    
    /*
     * Test the show red channel using the image in the folder BmpTest
     */
    @Test
    public void testShowChanelR() throws IOException{
        Image myImage = testImageIo.myRead(image1Path);
        Image myRedimage = testProcessor.showChanelR(myImage);
        
        Image rightImage = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/1_red_goal.bmp"); 
        
        assertTrue(compareImage(myRedimage, rightImage));
        
        Image myImage2 = testImageIo.myRead(image2Path);
        Image myRedimage2 = testProcessor.showChanelR(myImage2);
        
        Image rightImage2 = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/2_red_goal.bmp");
        assertTrue(compareImage(myRedimage2, rightImage2));
    }
    
    
    /*
     * Test the show green channel using the image in the folder BmpTest
     */
    @Test
    public void testShowChanelG() throws IOException{
        Image myImage = testImageIo.myRead(image1Path);
        Image myRedimage = testProcessor.showChanelG(myImage);
        
        Image rightImage = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/1_green_goal.bmp"); 
        
        assertTrue(compareImage(myRedimage, rightImage));
        
        Image myImage2 = testImageIo.myRead(image2Path);
        Image myRedimage2 = testProcessor.showChanelG(myImage2);
        
        Image rightImage2 = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/2_green_goal.bmp");
        assertTrue(compareImage(myRedimage2, rightImage2));
    }
    
    /*
     * Test the show blue channel using the image in the folder BmpTest
     */
    @Test
    public void testShowChanelB() throws IOException{
        Image myImage = testImageIo.myRead(image1Path);
        Image myRedimage = testProcessor.showChanelB(myImage);
        
        Image rightImage = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/1_blue_goal.bmp"); 
        
        assertTrue(compareImage(myRedimage, rightImage));
        
        Image myImage2 = testImageIo.myRead(image2Path);
        Image myRedimage2 = testProcessor.showChanelB(myImage2);
        
        Image rightImage2 = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/2_blue_goal.bmp");
        assertTrue(compareImage(myRedimage2, rightImage2));
    }
    
    
    /*
     * Test the show gray channel using the image in the folder BmpTest
     */
    @Test
    public void testShowGray() throws IOException{
        Image myImage = testImageIo.myRead(image1Path);
        Image myRedimage = testProcessor.showGray(myImage);
        
        Image rightImage = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/1_gray_goal.bmp"); 
        
        assertTrue(compareImage(myRedimage, rightImage));
        
        Image myImage2 = testImageIo.myRead(image2Path);
        Image myRedimage2 = testProcessor.showGray(myImage2);
        
        Image rightImage2 = testImageIo.myRead("/home/qiuxy/Desktop/final/ImageProcessing/bmptest/goal/2_gray_goal.bmp");
        assertTrue(compareImage(myRedimage2, rightImage2));
    }
    
    
    /*
     * In this private function, we will test if myImgae if the same as the rightImgae
     * We will check their their RGB number of every pixel 
     */
    private boolean compareImage(Image myImage, Image rightImage) {
        int myWidth = myImage.getWidth(null);
        int myHeight = myImage.getHeight(null);
        int rightWidth = rightImage.getWidth(null);
        int rightHeight = rightImage.getHeight(null);
        
        if(myWidth != rightWidth || myHeight != rightHeight) {
            return false;
        }
        
        BufferedImage mybuffer = new BufferedImage(myWidth, myHeight, BufferedImage.TYPE_INT_RGB);
		Graphics2D myGraph = mybuffer.createGraphics();
		myGraph.drawImage(myImage, 0, 0, null);		
	    BufferedImage rightbuffer = new BufferedImage(rightWidth, rightHeight, BufferedImage.TYPE_INT_RGB);
	    Graphics2D rightGraph = rightbuffer.createGraphics();
		rightGraph.drawImage(rightImage, 0, 0, null);
	    for (int i = 0; i < myHeight; i++) {
	    	for (int j = 0; j < myWidth; j++) {
	    		if (mybuffer.getRGB(j, i) != rightbuffer.getRGB(j, i)) {
	    			return false;
	    		}
	    	}
	    }
	    return true;
    }
    
}











