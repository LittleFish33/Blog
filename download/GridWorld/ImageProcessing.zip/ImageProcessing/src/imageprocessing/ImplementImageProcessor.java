package imageprocessing;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.FilteredImageSource;
import java.awt.image.RGBImageFilter;

import imagereader.IImageProcessor;

/*
 * show the red,blue,green or gray channel
 */
enum ChangeMode{
    RED,BLUE,GREEN,GRAY
}

/*
 * This class inherit the RGBImageFilter, it help us to filter the color of the image
 */
class MyImageFilter extends RGBImageFilter{
    
    private ChangeMode mode;
    
    /*
     * constructor function,get the mode we want to filter
     */
    public MyImageFilter(ChangeMode m) {
        mode = m;
    }
    
    /*
     * filter the color
     * @see java.awt.image.RGBImageFilter#filterRGB(int, int, int)
     * @param rgb the RGB value we want to filter
     */
    @Override
    public int filterRGB(int x, int y, int rgb) {
        if(mode == ChangeMode.RED) {
            return rgb & 0xffff0000;
        }
        else if(mode == ChangeMode.GREEN) {
            return rgb & 0xff00ff00;
        }
        else if(mode == ChangeMode.BLUE) {
            return rgb & 0xff0000ff;
        }
        else {
            int red = (int)(((rgb & 0x00ff0000) >> 16) * 0.299);
            int green = (int)(((rgb & 0x0000ff00) >> 16) * 0.587);
            int blue = (int)(((rgb & 0x000000ff) >> 16) * 0.114);
            int result =  red + blue + green;
            return (rgb & 0xff000000) + (result << 16) + (result << 8) + result;
        }
    }
    
}

/*
 * This class inherit the IImageProcessor, it help us to process the image
 */
public class ImplementImageProcessor implements IImageProcessor {

    /*
     * show the blue channel of the image
     * @see imagereader.IImageProcessor#showChanelB(java.awt.Image)
     */
    @Override
    public Image showChanelB(Image image) {
        return getImage(image, ChangeMode.BLUE);
    }

    /*
     * show the green channel of the image
     * @see imagereader.IImageProcessor#showChanelG(java.awt.Image)
     */
    @Override
    public Image showChanelG(Image image) {
        return getImage(image, ChangeMode.GREEN);
    }

    /*
     * show the red channel of the image
     * @see imagereader.IImageProcessor#showChanelR(java.awt.Image)
     */
    @Override
    public Image showChanelR(Image image) {
        return getImage(image, ChangeMode.RED);
    }

    /*
     * show the gray channel of the image
     * @see imagereader.IImageProcessor#showGray(java.awt.Image)
     */
    @Override
    public Image showGray(Image image) {
        return getImage(image, ChangeMode.GRAY);
    }
    
    //according the mode given, get the image after filter
    private Image getImage(Image image, ChangeMode mode) {
        MyImageFilter redFilter = new MyImageFilter(mode);
        Toolkit toolKit = Toolkit.getDefaultToolkit();
        return toolKit.createImage(new FilteredImageSource(image.getSource(), redFilter));
    }
}
