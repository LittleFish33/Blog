package imageprocessing;

import imagereader.Runner;

/**
 * This class runs the  ImplementImageIO class and ImplementProcessor class <br />
 * It first create a window, you can select a image from the menu, after choose a image
 * You can decide show the red,green,blue,gray channel of the image,
 * also, you can save the image
 */
public final class ImagaReaderRunner {
    
    private ImagaReaderRunner() {}
    public static void main(String[] args) {
        ImplementImageIO imageioer = new ImplementImageIO();
        ImplementImageProcessor processor = new ImplementImageProcessor();
        Runner.run(imageioer, processor);
    }
}
