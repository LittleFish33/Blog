package imageprocessing;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

import imagereader.*;


/*
 * This class inherit the IImageIO, we will use this class to read and save the image
 */
public class ImplementImageIO implements IImageIO
{
    /*
     * override the read method, read the image in the filePath
     * @param filePath the path of the image
     */
    @Override
    public Image myRead(String filePath) throws IOException {
        
        // read the file and get the inputStream
        File file = new File(filePath);
        FileInputStream fileInputStream = new FileInputStream(file);
        
        //skip the header information we don't need
        fileInputStream.skip(18);
        
        //we will use this array to get the information we need
        byte temp[] = new byte[4];
        //get the width of the image
        fileInputStream.read(temp);
        int imageWidth = convertToInt(temp,4);
        //get the height of the image
        fileInputStream.read(temp);
        int imageHeight = convertToInt(temp, 4);
        
        
        fileInputStream.skip(8);
        fileInputStream.read(temp);
        /*
         * get the raw size of the image
         * using the rawSize, we can get the number of byte we need to skip when we rend the image
         */
        int rawSize = convertToInt(temp, 4);
        int skipNumber = rawSize / imageHeight - 3 * imageWidth;
        int bitMapData[] = new int[imageHeight * imageWidth];
        
        // skip to the pixels
        fileInputStream.skip(16);
        byte[] color = new byte[3];
        for(int i =  imageHeight - 1;i >= 0;i--) {
            for (int j = 0; j < imageWidth; j++) {
                //get the color of the pixel
                fileInputStream.read(color);
                bitMapData[imageWidth * i + j] = convertToInt(color, 3);
                bitMapData[imageWidth * i + j] |= (0xff << 24);
            }
            if(skipNumber != 0) {
                fileInputStream.skip(skipNumber);
            }
        }
        
        fileInputStream.close();
        
        //using the data array to get the image
        return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(imageWidth, imageHeight, bitMapData, 0, imageWidth));
    }

    /*
     * convert the byte array to int
     * @param byteArray the byte array we want to convert
     * @param size the size of the
     */
    private int convertToInt(byte[] byteArray,int size) {
        int res = 0;
        for(int i = 0;i < size;i++) {
            res |= ((byteArray[i] & 0xFF)  << (i * 8));
        }
        return res;
    }
    

    /*
     * save the image
     * @see imagereader.IImageIO#myWrite(java.awt.Image, java.lang.String)
     * @param image the image we want to save
     * @param filePath the path we want to save
     */
    @Override
    public Image myWrite(Image image, String filePath) throws IOException {
        int width = image.getWidth(null);
        int height = image.getHeight(null);
        BufferedImage bufImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        
        Graphics2D graphics2d = bufImage.createGraphics();
        graphics2d.drawImage(image, null, null);
        
        ImageIO.write(bufImage, "bmp", new File(filePath));        
        
        return image;
    }
}
