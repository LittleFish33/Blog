package solution;

import java.util.LinkedList;
import java.util.Queue;
import jigsaw.Jigsaw;
import jigsaw.JigsawNode;


/**
 * 在此类中填充算法，完成重拼图游戏（N-数码问题）
 */
public class Solution extends Jigsaw {

	/**
	 * 拼图构造函数
	 */
	public Solution() {
	}

	/**
	 * 拼图构造函数
	 * @param bNode - 初始状态节点
	 * @param eNode - 目标状态节点
	 */
	public Solution(JigsawNode bNode, JigsawNode eNode) {
		super(bNode, eNode);
	}

	/**
	 *（实验一）广度优先搜索算法，求指定5*5拼图（24-数码问题）的最优解
     * 填充此函数，可在Solution类中添加其他函数，属性
	 * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
	 * @return 搜索成功时为true,失败为false
	 */
	public boolean BFSearch(JigsawNode bNode, JigsawNode eNode) {
		beginJNode = bNode;
		endJNode = eNode;
		currentJNode = beginJNode;
	    Queue<JigsawNode> openQueue = new LinkedList<>();
	    openQueue.add(currentJNode);
	    Queue<JigsawNode> closeQueue = new LinkedList<>();
	    while (!openQueue.isEmpty()) {
	    	if(currentJNode.equals(endJNode)) {
	    		getPath();
	    		System.out.println(getSolutionPath());
	    		return true;
	    	}
	    	else {
	    		int arr[] = currentJNode.canMove();
	    		for (int i = 0; i < 4; i++) {
	    			if(arr[i] == 1) {
			    		JigsawNode tempNode = new JigsawNode(currentJNode);
			    		tempNode.move(i);
			    		if(!closeQueue.contains(tempNode)) {
			    			openQueue.add(tempNode);
			    		}
	    			}
				}
	    		openQueue.remove();
	    		closeQueue.add(currentJNode);
	    		currentJNode = openQueue.peek();
	    	}
	    }
	    System.out.println(false);
	    return false;
	}

	/**
	 *（Demo+实验二）计算并修改状态节点jNode的代价估计值:f(n)
	 * 如 f(n) = s(n). s(n)代表后续节点不正确的数码个数
     * 此函数会改变该节点的estimatedValue属性值
     * 修改此函数，可在Solution类中添加其他函数，属性
	 * @param jNode - 要计算代价估计值的节点
	 */
	public void estimateValue(JigsawNode jNode) {
		int []curArr = jNode.getNodesState();
		int []endArr = getEndJNode().getNodesState();
		int s = 0;		
		int f2 = 0;		// 曼哈顿距离
		int f3 = 0;		// 绝对距离
		int dimension = JigsawNode.getDimension();
		int x1 = 0,x2 = 0,y1 = 0,y2 = 0;
		
		for (int index = 1; index < dimension * dimension; index++) {
			if (curArr[index] + 1 != curArr[index + 1]) {
				s++;
			}
			if(curArr[index] != endArr[index] && curArr[0] != index) {
				f2++;
				x1 = (curArr[index] - 1)/dimension;
				y1 = (curArr[index] - 1)%dimension;
				x2 = (endArr[index] - 1)/dimension;
				y2 = (endArr[index] - 1)%dimension;
				f2 += Math.abs(x1 - x2) + Math.abs(y1 - y2);
				f3 += Math.sqrt(Math.abs(x1-x2)) + Math.sqrt(Math.abs(y1-y2));
			}
			
		}
		jNode.setEstimatedValue(s * 0 + f2 * 10 + f3 * 6);
	}
}
