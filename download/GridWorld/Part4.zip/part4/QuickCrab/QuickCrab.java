import java.util.ArrayList;
import info.gridworld.grid.Location;


public class QuickCrab extends CrabCritter {
    
    //the QuickCrab can move two steps, so the getMoveLocations will get the locations accessible within two steps
    public ArrayList<Location> getMoveLocations()
    {
        
        Location leftloc = getLocation().getAdjacentLocation(getDirection() +  Location.LEFT);
        Location rightLoc = getLocation().getAdjacentLocation(getDirection() + Location.RIGHT);
        ArrayList<Location> moveLocs = new ArrayList<Location>();
        if(getGrid().isValid(leftloc) && getGrid().get(leftloc) == null) {
            leftloc = leftloc.getAdjacentLocation(getDirection() + Location.LEFT);
            if(getGrid().isValid(leftloc) && getGrid().get(leftloc) == null) {
                moveLocs.add(leftloc);
            }
        }
        if(getGrid().isValid(rightLoc) && getGrid().get(rightLoc) == null) {
            rightLoc = rightLoc.getAdjacentLocation(getDirection() + Location.RIGHT);
            if(getGrid().isValid(rightLoc) && getGrid().get(rightLoc) == null) {
                moveLocs.add(rightLoc);
            }
        }
        if(moveLocs.isEmpty()) {
            return super.getMoveLocations();
        }
        else {
            return moveLocs;
        }
    }
    
    
}
