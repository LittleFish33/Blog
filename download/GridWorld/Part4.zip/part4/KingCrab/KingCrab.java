import info.gridworld.actor.*;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;

import java.util.ArrayList;

public class KingCrab extends CrabCritter 
{
    //override the processActors method
    public void processActors(ArrayList<Actor> actors) {
        ArrayList<Location> twoStepLocations = getTwoStepLocations();
        //search the actor, if the actor is not the rock, process it
        for (Actor actor : actors) {
            if(!(actor instanceof Rock)) {
                //get the location of the actor
                Location actorLocation = actor.getLocation();
                //if the flag is still true after the loop, then the actor can not move, remove it
                boolean flag = true;
                for (int i = 0; i < twoStepLocations.size(); i++) {
                    if(Math.abs(actorLocation.getCol() - twoStepLocations.get(i).getCol()) <= 1 && 
                            Math.abs(actorLocation.getRow() - twoStepLocations.get(i).getRow()) <= 1) {
                        actor.moveTo(twoStepLocations.get(i));
                        flag = false;
                        break;
                    }
                }
                if(flag) {
                    actor.removeSelfFromGrid();
                }
            }
        }
    }
    
    private ArrayList<Location> getTwoStepLocations(){
        Grid<Actor> world = getGrid();
        ArrayList<Location> twoStepLocations = new ArrayList<Location>();
        Location location = getLocation();
        //first get all the location that is two steps away from the KingCrab
        for(int i = location.getRow()-2;i <= location.getRow() + 2;i++) {
            for(int j = location.getCol() - 2;j <= location.getCol() + 2;j++) {
                //two steps away from, add to the twoStepLocations
                if(Math.abs(i - location.getRow()) == 2 || Math.abs(j - location.getCol()) == 2) {
                    Location temp = new Location(i, j);
                    if (world.isValid(temp) && world.get(temp) == null) {
                        twoStepLocations.add(temp);
                    }
                }   
            }
        }
        return twoStepLocations;
    
    }
}

