import java.awt.Color;

import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

/**
 * A <code>BlusterCritter</code> looks at all of the neighbors within two steps
 * of its current location. (For a BlusterCritter not near an edge, this
 * includes 24 locations). <br />
 */
public class BlusterCritter extends Critter {
    private static final double DARKENING_FACTOR = 0.05;
    private int value;
    
    //initialize the value
    public BlusterCritter(int v) {
        this.value = v;
    }
    
    public void act()
    {
        super.act();
        //get the number of the Critters within two step
        int number = getTwoStepCritter();
        //if the number is smaller than the value,go light,else, go dark
        if(number < value){
            goLight();
        }
        else {
            goDark();
        }
        
    }
    
    //get the number of the Critters within two step
    private int getTwoStepCritter() {
        //because the BlusterCritter itself is a crister, so the initialize number should be -1
        int number = -1;
        Location location = getLocation();
        for(int i = location.getRow()-2;i <= location.getRow() + 2;i++) {
            for(int j = location.getCol()-2;j <= location.getCol() + 2;j++) {
                Location temp = new Location(i, j);
                if (getGrid().isValid(temp) && getGrid().get(temp) instanceof Critter) {
                    number++;
                }
            }
        }
        return number;
    }


    private void goDark() {
        //get the color of the BlusterCritter, and the decrease the rgb number
        Color c = getColor();
        int red = (int) (c.getRed() * (1 - DARKENING_FACTOR));
        int green = (int) (c.getGreen() * (1 - DARKENING_FACTOR));
        int blue = (int) (c.getBlue() * (1 - DARKENING_FACTOR));
        this.setColor(new Color(red, green, blue));
    }
    
    //increase the rgb number, the number is bigger than 255, then do nothing
    private void goLight() {
        Color c = getColor();
        int red = c.getRed();
        int green = c.getGreen();
        int blue = c.getBlue();
        if(red < 255) {
            red++;
        }
        if(green < 255) {
            green++;
        }
        if(blue < 255) {
            blue++;
        }
        this.setColor(new Color(red, green, blue));
    }
    
    
}
