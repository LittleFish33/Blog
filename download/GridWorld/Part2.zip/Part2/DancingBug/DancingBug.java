import info.gridworld.actor.Bug;

public class DancingBug extends Bug
{
    private int[] array;
    private int count;
    private int length;
    private int turnTimes;
    
    /**
     * Constructs a Dancing bug with a array
     * @param length the side length
     */
    public DancingBug(int []arr)
    {
        length = arr.length;
        turnTimes = 0;
        array = new int[arr.length];
        System.arraycopy(arr, 0, array, 0, length);
        count = 0;
    }

	/**
     * Moves to the next location of the square after turn according to the array
     */
    public void act()
    {
        if(turnTimes < array[count]) {
            turnTimes++;
            turn();
        }
        else {
            turnTimes = 0;
            count = (count+1)%length;
            if(canMove()) {
                move();
            }
        }
    }
}
