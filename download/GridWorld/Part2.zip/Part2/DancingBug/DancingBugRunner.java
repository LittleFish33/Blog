import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;


/**
 * This class runs a world that contains Dancing bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public final class DancingBugRunner {

    private DancingBugRunner(){}
    
    public static void main(String[] args) throws InterruptedException
    {
        ActorWorld world = new ActorWorld();
        int arry[] = {1,2,3,4,5};
        DancingBug alice = new DancingBug(arry);
        alice.setColor(Color.ORANGE);
        world.add(new Location(4, 4), alice);
        world.show();
    }

}
