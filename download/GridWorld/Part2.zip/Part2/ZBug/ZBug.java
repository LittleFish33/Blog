import info.gridworld.actor.Bug;

public class ZBug extends Bug
{
    private int steps;
    private int sideLength;
    private int count;

    /**
     * Constructs a Z bug that move in a “Z” pattern
     * @param length the side length
     */
    public ZBug(int length)
    {
        steps = 0;
        sideLength = length;
        count = 0;
        turn();
        turn();
    }

    /**
     * Moves to the next location of the square.
     */
    public void act()
    {
        if(!canMove()) {
            return;
        }

        if (steps < sideLength)
        {
            move();
            steps++;
        }
        else if(count == 0)
        {
            turn();
            turn();
            turn();
            count++;
            steps = 0;
        }
        else if(count == 1){
            turn();
            turn();
            turn();
            turn();
            turn();
            steps = 0;
            count++;
        }
    }
}
