import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;

/**
 * This class runs a world that contains Z bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public final class ZBugRunner {

    private ZBugRunner(){}
    
    public static void main(String[] args) throws InterruptedException
    {
        ActorWorld world = new ActorWorld();
        ZBug alice = new ZBug(6);
        alice.setColor(Color.ORANGE);
        world.add(new Location(9, 9), alice);
        world.show();
    }
}
