import java.awt.Color;

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
/**
 * This class runs a world that contains Spiral bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public final class SpiralBugRunner {

    private SpiralBugRunner(){}
    public static void main(String[] args) throws InterruptedException
    {
        ActorWorld world = new ActorWorld();
        SpiralBug alice = new SpiralBug(6);
        alice.setColor(Color.ORANGE);
        world.add(new Location(9, 9), alice);
        world.show();
    }
}
