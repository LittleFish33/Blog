package info.gridworld.maze;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Stack;

import javax.swing.JOptionPane;

/**
 * A <code>MazeBug</code> can find its way in a maze. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class MazeBug extends Bug {
    private Location next;
    private Location last;
    private boolean isEnd = false;
    private Stack<Location> crossLocation = new Stack<Location>();
    private Integer stepCount = 0;
    //final message has been shown
    private boolean hasShown = false;
    private int []direction = {Location.NORTH, Location.EAST,Location.SOUTH,Location.WEST};
    private int []probabilityMatrix = new int[4];
    private boolean firstAct = true;
    /**
     * Constructs a box bug that traces a square of a given side length
     * 
     * @param length
     *            the side length
     */
    public MazeBug() {
        setColor(Color.GREEN);
        last = new Location(0, 0);
        for (int i = 0; i < probabilityMatrix.length; i++) {
            probabilityMatrix[i] = 1;
        }
    }

    /**
     * Moves to the next location of the square.
     */
    public void act() {
        if(firstAct) {
            crossLocation.add(getLocation());
            firstAct = false;
        }
        
        last = getLocation();
        if (isEnd) {
        //to show step count when reach the goal        
            if (!hasShown) {
                String msg = stepCount.toString() + " steps";
                JOptionPane.showMessageDialog(null, msg);
                hasShown = true;
            }
        } else if (canMove()) {
            move();
            //increase step count when move 
            stepCount++;
        }
        else {
            /*
             * If there is no way to move ahead, move back to the last location
             */
            if(crossLocation.size() > 1) {
                crossLocation.pop();
                Location top = crossLocation.peek();
                moveTo(top);
                stepCount++;
                Flower flower = new Flower(getColor());
                flower.putSelfInGrid(getGrid(), last);
                setDirection(last.getDirectionToward(top));
            }
        }
    }

    /**
     * Find all positions that can be move to.
     * 
     * @param loc
     *            the location to detect.
     * @return List of positions.
     */
    public ArrayList<Location> getValid(Location loc) {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            return null;
        }
        ArrayList<Location> valid = new ArrayList<Location>();
        for (int i = 0; i < 4; i++) {
            Location adjacentLoc = this.getLocation().getAdjacentLocation(direction[i]);
            if(gr.isValid(adjacentLoc)) {
                if(gr.get(adjacentLoc) == null) {
                    valid.add(adjacentLoc);
                }
                else{
                    Actor actor = gr.get(adjacentLoc);
                    if(actor != null && actor instanceof Rock && actor.getColor().equals(Color.RED)) {
                        isEnd = true;
                        valid.clear();
                        valid.add(adjacentLoc);
                        break;
                    }
                }
            }
        }
        
        return valid;
    }

    /**
     * Tests whether this bug can move forward into a location that is empty or
     * contains a flower.
     * 
     * @return true if this bug can move.
     */
    public boolean canMove() {
         return getValid(this.getLocation()).size() > 0;
    }
    /**
     * Moves the bug forward, putting a flower into the location it previously
     * occupied.
     */
    public void move() {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            return;
        }
        Location loc = getLocation();
        
        ArrayList<Location> validLocation = getValid(getLocation());
        getNextLocation(validLocation);
        
        if (gr.isValid(next)) {
            setDirection(getLocation().getDirectionToward(next));
            crossLocation.push(next);
            moveTo(next);
            last = next;
            next = null;
        }
        Flower flower = new Flower(getColor());
        flower.putSelfInGrid(gr, loc);
    }
    
    
    /*
     * Using the probabilityMatrix to get the next location
     */
    private void getNextLocation(ArrayList<Location> validLocation) {
        Location myLocation = getLocation();
        ArrayList<Integer> container = new ArrayList<>();
        int dir,count = 0;
        
        for (Location location : validLocation) {
            dir = myLocation.getDirectionToward(location) / 90;
            for (int i = 0; i < probabilityMatrix[dir]; i++) {
                container.add(count);
            }
            count ++;
        }
        
        //Use the random function
        int random = (int) (Math.random() * container.size());
        int selectDirection = container.get(random);
        // set the next location
        next = validLocation.get(selectDirection);
        //update the value
        probabilityMatrix[myLocation.getDirectionToward(next)/90]++;
    }
}
